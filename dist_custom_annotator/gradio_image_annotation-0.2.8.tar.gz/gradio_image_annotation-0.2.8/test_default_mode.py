#!/usr/bin/env python3

import gradio as gr
from gradio_image_annotation import image_annotator

def test_default_modes():
    """Test different default shape creation modes"""
    
    # Test 1: Default mode (should be drag)
    print("Test 1: Default mode")
    annotator_default = image_annotator()
    print(f"Default shape_creation_mode: {annotator_default.shape_creation_mode}")
    assert annotator_default.shape_creation_mode == "drag", f"Expected 'drag', got '{annotator_default.shape_creation_mode}'"
    
    # Test 2: Explicit drag mode
    print("Test 2: Explicit drag mode")
    annotator_drag = image_annotator(shape_creation_mode="drag")
    print(f"Explicit drag shape_creation_mode: {annotator_drag.shape_creation_mode}")
    assert annotator_drag.shape_creation_mode == "drag", f"Expected 'drag', got '{annotator_drag.shape_creation_mode}'"
    
    # Test 3: Box mode
    print("Test 3: Box mode")
    annotator_box = image_annotator(shape_creation_mode="box")
    print(f"Box shape_creation_mode: {annotator_box.shape_creation_mode}")
    assert annotator_box.shape_creation_mode == "box", f"Expected 'box', got '{annotator_box.shape_creation_mode}'"
    
    # Test 4: Circle mode
    print("Test 4: Circle mode")
    annotator_circle = image_annotator(shape_creation_mode="circle")
    print(f"Circle shape_creation_mode: {annotator_circle.shape_creation_mode}")
    assert annotator_circle.shape_creation_mode == "circle", f"Expected 'circle', got '{annotator_circle.shape_creation_mode}'"
    
    # Test 5: Freehand mode
    print("Test 5: Freehand mode")
    annotator_freehand = image_annotator(shape_creation_mode="freehand")
    print(f"Freehand shape_creation_mode: {annotator_freehand.shape_creation_mode}")
    assert annotator_freehand.shape_creation_mode == "freehand", f"Expected 'freehand', got '{annotator_freehand.shape_creation_mode}'"
    
    # Test 6: Polygon mode
    print("Test 6: Polygon mode")
    annotator_polygon = image_annotator(shape_creation_mode="polygon")
    print(f"Polygon shape_creation_mode: {annotator_polygon.shape_creation_mode}")
    assert annotator_polygon.shape_creation_mode == "polygon", f"Expected 'polygon', got '{annotator_polygon.shape_creation_mode}'"
    
    print("All tests passed! ✅")
    return True

if __name__ == "__main__":
    test_default_modes()
