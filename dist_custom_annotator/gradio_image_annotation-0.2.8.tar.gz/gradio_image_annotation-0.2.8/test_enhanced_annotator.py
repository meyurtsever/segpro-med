import gradio as gr
import sys
import os

# Add the backend path to Python path
backend_path = os.path.join(os.path.dirname(__file__), 'backend')
sys.path.insert(0, backend_path)

from gradio_image_annotation import image_annotator

def test_annotator():
    # Test the updated image annotator with all new features
    test_value = {
        "image": "https://raw.githubusercontent.com/gradio-app/gradio/main/guides/assets/logo.png",
        "boxes": [
            {
                "xmin": 30,
                "ymin": 70,
                "xmax": 530,
                "ymax": 500,
                "label": "Regular Box",
                "color": (250, 185, 0),
                "type": "box"
            },
            {
                "type": "freehand",
                "points": [{"x": 100, "y": 100}, {"x": 150, "y": 120}, {"x": 200, "y": 100}],
                "label": "Freehand Path",
                "color": (0, 255, 0),
                "xmin": 100,
                "ymin": 100,
                "xmax": 200,
                "ymax": 120
            },
            {
                "type": "circle", 
                "centerX": 300,
                "centerY": 200,
                "radius": 50,
                "label": "Circle",
                "color": (255, 0, 0),
                "xmin": 250,
                "ymin": 150,
                "xmax": 350,
                "ymax": 250
            },
            {
                "type": "polygon",
                "points": [{"x": 400, "y": 300}, {"x": 450, "y": 320}, {"x": 430, "y": 350}, {"x": 380, "y": 340}],
                "label": "Polygon",
                "color": (0, 0, 255),
                "xmin": 380,
                "ymin": 300,
                "xmax": 450,
                "ymax": 350
            }
        ]
    }
      # Create annotator with all new features enabled
    annotator = image_annotator(
        value=test_value,
        label_list=["Regular Box", "Freehand Path", "Circle", "Polygon", "Erased Area"],
        label_colors=["#FAB900", "#00FF00", "#FF0000", "#0000FF", "#800080"],
        eraser_size=15,
        enable_freehand=True,
        enable_circle=True,        enable_polygon=True,
        enable_eraser=True,
        shape_creation_mode="drag",  # Default mode is now drag
        box_thickness=3,
        box_selected_thickness=5,
        handles_cursor=True,
        use_default_label=False  # Ensure modal appears for shape labeling
    )
    
    def process_annotation(annotation_data):
        if annotation_data:
            print("Received annotation data:")
            print(f"Number of shapes: {len(annotation_data.get('boxes', []))}")
            for i, box in enumerate(annotation_data.get('boxes', [])):
                print(f"  Shape {i+1}: {box.get('type', 'box')} - {box.get('label', 'No label')}")
        return annotation_data

    # Create the interface
    iface = gr.Interface(
        fn=process_annotation,
        inputs=annotator,
        outputs=annotator,
        title="Enhanced Image Annotator Test",
        description="""
        This is a test of the enhanced image annotator with all new features:
        
        **Drawing Modes:**
        - Box: Traditional rectangular bounding boxes
        - Freehand: Draw custom paths with mouse/touch
        - Circle: Draw circular shapes 
        - Polygon: Click to add points, Space or click start point to finish
        - Eraser: Pixel-based erasing of shape areas
        
        **Enhanced Features:**
        - Advanced undo/redo system with dedicated clear history
        - Configurable eraser brush size
        - Support for multiple shape types in single annotation
        - Enhanced keyboard shortcuts (Ctrl+Z, Ctrl+Y, Delete, Space)
        
        **UI Features:**
        - Modal dialogs for shape editing
        - Drag mode for moving and resizing shapes
        - Label visibility toggle
        - Clear all shapes with recovery options
        """
    )
    
    return iface

if __name__ == "__main__":
    demo = test_annotator()
    demo.launch()
